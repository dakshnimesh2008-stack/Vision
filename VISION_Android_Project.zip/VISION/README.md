# VISION — Time. Your Way.

Native Android (Kotlin + Jetpack Compose + Material 3) clock customization app. Package: `com.daksh.vision`.

## Status: Stage 1 of 5
Done: project setup, theme (system/light/dark), brand loading screen, bottom navigation, Home (real time/date, 12/24h),
Settings (theme, time format, privacy, reset with confirmation, version), launcher icon, unit tests for time formatting.
Coming: Clocks (stage 2), Widgets (3), Smart AOD (4), final README/report (5).

## Build from a phone (GitHub Actions)
1. Create a GitHub repo and upload this folder's contents (keep the `.github` folder).
2. Open the **Actions** tab -> "Build VISION debug APK" -> Run workflow (it also runs on every push).
3. When it finishes, open the run and download the `VISION-debug-apk` artifact, unzip it, install `app-debug.apk`.

The workflow installs Gradle 8.7 itself, so no Gradle wrapper file is needed.

## Loading screen
- System splash (androidx core-splashscreen) is held only while settings are really loading.
- A ~1.1 s brand animation (V fade/scale, ring sweep, title) plays over the already-loaded Home screen on fresh launches only; it never delays the app.
- Skipped when system animations are turned off. A load failure shows a message with "Try again".

## Privacy
No internet permission, no accounts, no ads, no analytics.

## Not yet verified
Nothing has been compiled or run in the authoring environment (no Android SDK / network). First real compile happens in GitHub Actions.
