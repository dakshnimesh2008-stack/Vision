package com.daksh.vision.ui

import android.provider.Settings
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Settings as SettingsIcon
import androidx.compose.material.icons.outlined.Widgets
import androidx.compose.material.icons.outlined.Brightness4
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.daksh.vision.MainViewModel
import com.daksh.vision.UiState
import com.daksh.vision.ui.screens.AodScreen
import com.daksh.vision.ui.screens.ClocksScreen
import com.daksh.vision.ui.screens.HomeScreen
import com.daksh.vision.ui.screens.SettingsScreen
import com.daksh.vision.ui.screens.WidgetsScreen
import com.daksh.vision.ui.splash.BrandIntro
import com.daksh.vision.ui.splash.LoadingScreen
import com.daksh.vision.ui.theme.VisionTheme
import com.daksh.vision.data.ThemeMode

enum class Dest(val route: String, val label: String, val icon: ImageVector) {
    Home("home", "Home", Icons.Outlined.Home),
    Clocks("clocks", "Clocks", Icons.Outlined.Schedule),
    Widgets("widgets", "Widgets", Icons.Outlined.Widgets),
    Aod("aod", "Smart AOD", Icons.Outlined.Brightness4),
    Settings("settings", "Settings", Icons.Outlined.SettingsIcon),
}

@Composable
fun VisionRoot(vm: MainViewModel, playBrandIntro: Boolean) {
    val state by vm.state.collectAsState()
    val settings = (state as? UiState.Ready)?.settings
    val context = LocalContext.current
    // Respect system "remove animations": skip the brand intro entirely.
    val reducedMotion = remember(context) {
        Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    }
    var introDone by rememberSaveable { mutableStateOf(!playBrandIntro || reducedMotion) }

    VisionTheme(settings?.theme ?: ThemeMode.SYSTEM) {
        when (val s = state) {
            is UiState.Loading -> LoadingScreen(error = null, onRetry = vm::load)
            is UiState.Error -> LoadingScreen(error = s.message, onRetry = vm::load)
            is UiState.Ready -> Box(Modifier.fillMaxSize()) {
                MainScaffold(vm, s)
                if (!introDone) BrandIntro(onFinished = { introDone = true })
            }
        }
    }
}

@Composable
private fun MainScaffold(vm: MainViewModel, ready: UiState.Ready) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val current = backStack?.destination?.route
    val go: (Dest) -> Unit = { d ->
        nav.navigate(d.route) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }
    Scaffold(
        bottomBar = {
            NavigationBar {
                Dest.entries.forEach { d ->
                    NavigationBarItem(
                        selected = current == d.route,
                        onClick = { go(d) },
                        icon = { Icon(d.icon, contentDescription = d.label) },
                        label = { Text(d.label) },
                    )
                }
            }
        },
    ) { padding ->
        NavHost(nav, startDestination = Dest.Home.route, modifier = Modifier.padding(padding)) {
            composable(Dest.Home.route) { HomeScreen(ready.settings, onNavigate = go) }
            composable(Dest.Clocks.route) { ClocksScreen() }
            composable(Dest.Widgets.route) { WidgetsScreen() }
            composable(Dest.Aod.route) { AodScreen() }
            composable(Dest.Settings.route) { SettingsScreen(ready.settings, vm) }
        }
    }
}
