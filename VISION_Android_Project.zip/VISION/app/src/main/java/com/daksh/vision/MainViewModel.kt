package com.daksh.vision

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.daksh.vision.data.AppSettings
import com.daksh.vision.data.SettingsRepository
import com.daksh.vision.data.ThemeMode
import com.daksh.vision.data.TimeFormat
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

sealed interface UiState {
    data object Loading : UiState
    data class Ready(val settings: AppSettings) : UiState
    data class Error(val message: String) : UiState
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SettingsRepository(app)
    private val _state = MutableStateFlow<UiState>(UiState.Loading)
    val state: StateFlow<UiState> = _state
    private var job: Job? = null

    init { load() }

    /** Loads real persisted settings. Ready is emitted as soon as DataStore responds: no artificial delay. */
    fun load() {
        job?.cancel()
        _state.value = UiState.Loading
        job = viewModelScope.launch {
            repo.settings
                .catch { _state.value = UiState.Error(it.message ?: "Could not read settings") }
                .collect { _state.value = UiState.Ready(it) }
        }
    }

    fun setTheme(mode: ThemeMode) = viewModelScope.launch { repo.setTheme(mode) }
    fun setTimeFormat(format: TimeFormat) = viewModelScope.launch { repo.setTimeFormat(format) }
    fun resetAll() = viewModelScope.launch { repo.resetAll() }
}
