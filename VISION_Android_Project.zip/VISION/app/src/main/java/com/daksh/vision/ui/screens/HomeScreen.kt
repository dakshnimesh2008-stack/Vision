package com.daksh.vision.ui.screens

import android.text.format.DateFormat
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import com.daksh.vision.data.AppSettings
import com.daksh.vision.data.TimeFormat
import com.daksh.vision.ui.Dest
import com.daksh.vision.util.TimeFormatter
import kotlinx.coroutines.delay
import java.time.LocalDateTime

/** Real device time. Ticks once per second boundary, and only while the app is visible (STARTED). */
@Composable
fun rememberNow(): LocalDateTime {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    val owner = LocalLifecycleOwner.current
    LaunchedEffect(owner) {
        owner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (true) {
                now = LocalDateTime.now()
                delay(1000L - (System.currentTimeMillis() % 1000L))
            }
        }
    }
    return now
}

@Composable
fun resolveUse24h(settings: AppSettings): Boolean = when (settings.timeFormat) {
    TimeFormat.H24 -> true
    TimeFormat.H12 -> false
    TimeFormat.SYSTEM -> DateFormat.is24HourFormat(LocalContext.current)
}

@Composable
fun HomeScreen(settings: AppSettings, onNavigate: (Dest) -> Unit) {
    val now = rememberNow()
    val use24h = resolveUse24h(settings)
    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("VISION", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        Column(Modifier.fillMaxWidth().padding(vertical = 24.dp)) {
            Row {
                Text(TimeFormatter.time(now, use24h, showSeconds = false), style = MaterialTheme.typography.displayLarge)
                val ampm = TimeFormatter.amPm(now, use24h)
                if (ampm.isNotEmpty()) {
                    Text(ampm, style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 8.dp, top = 28.dp))
                }
            }
            Text(TimeFormatter.date(now), style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        ShortcutCard("Clocks", "Browse, preview and customize clock designs", Dest.Clocks, onNavigate)
        ShortcutCard("Widgets", "Add a clock to your home screen", Dest.Widgets, onNavigate)
        ShortcutCard("Smart AOD", "Rules for when your clock display is active", Dest.Aod, onNavigate)
    }
}

@Composable
private fun ShortcutCard(title: String, subtitle: String, dest: Dest, onNavigate: (Dest) -> Unit) {
    Card(
        Modifier.fillMaxWidth().clickable { onNavigate(dest) },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
