package com.daksh.vision.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

// Stage 1 only: these three sections are filled in by Stages 2-4 and replaced then.
@Composable private fun StageScreen(title: String, body: String) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium)
        Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
@Composable fun ClocksScreen() = StageScreen("Clocks", "The clock library arrives in the next stage.")
@Composable fun WidgetsScreen() = StageScreen("Widgets", "Home-screen widgets arrive in a later stage.")
@Composable fun AodScreen() = StageScreen("Smart AOD", "Smart AOD rules arrive in a later stage.")
