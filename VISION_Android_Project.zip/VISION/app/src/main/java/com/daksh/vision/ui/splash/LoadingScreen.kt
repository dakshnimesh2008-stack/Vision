package com.daksh.vision.ui.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Brand intro overlay: plays ~1.1 s on a fresh launch ON TOP of the already-loaded Home screen,
 * so it never delays the app. Sequence: V fades/scales in -> ring sweeps -> title -> fade out.
 */
@Composable
fun BrandIntro(onFinished: () -> Unit) {
    val vAlpha = remember { Animatable(0f) }
    val scale = remember { Animatable(0.88f) }
    val sweep = remember { Animatable(0f) }
    val title = remember { Animatable(0f) }
    val overlay = remember { Animatable(1f) }

    LaunchedEffect(Unit) {
        // Run the first three concurrently by launching them in sequence-light fashion.
        vAlpha.animateTo(1f, tween(350))
        scale.animateTo(1f, tween(250))
        sweep.animateTo(360f, tween(450, easing = LinearEasing))
        title.animateTo(1f, tween(200))
        overlay.animateTo(0f, tween(250))
        onFinished()
    }

    Box(
        Modifier.fillMaxSize().alpha(overlay.value).background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            BrandMark(
                ringColor = MaterialTheme.colorScheme.primary,
                vColor = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.scale(scale.value),
                ringSweep = sweep.value,
                vAlpha = vAlpha.value,
            )
            Spacer(Modifier.height(20.dp))
            Text(
                "VISION",
                style = MaterialTheme.typography.headlineMedium.copy(letterSpacing = 8.sp),
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.alpha(title.value),
            )
            Text(
                "Time. Your Way.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.alpha(title.value).padding(top = 6.dp),
            )
        }
    }
}

/** Shown only while real initialization is running (Loading) or has failed (error != null). */
@Composable
fun LoadingScreen(error: String?, onRetry: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center,
    ) {
        if (error == null) {
            val rotation by rememberInfiniteTransition(label = "ring").animateFloat(
                initialValue = 0f, targetValue = 360f,
                animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart),
                label = "rot",
            )
            BrandMark(
                ringColor = MaterialTheme.colorScheme.primary,
                vColor = MaterialTheme.colorScheme.onBackground,
                ringSweep = 90f, ringRotation = rotation,
            )
        } else {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.padding(32.dp),
            ) {
                Text("VISION couldn't start", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onBackground)
                Text(
                    "Your saved settings couldn't be read. $error",
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Button(onClick = onRetry) { Text("Try again") }
            }
        }
    }
}
