package com.daksh.vision.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsStore by preferencesDataStore(name = "vision_settings")

/** Persists app-wide preferences locally with DataStore. No network, no accounts. */
class SettingsRepository(private val context: Context) {
    private val themeKey = stringPreferencesKey("theme")
    private val formatKey = stringPreferencesKey("time_format")

    val settings: Flow<AppSettings> = context.settingsStore.data.map { it.toSettings() }

    suspend fun setTheme(mode: ThemeMode) = context.settingsStore.edit { it[themeKey] = mode.name }
    suspend fun setTimeFormat(format: TimeFormat) = context.settingsStore.edit { it[formatKey] = format.name }
    suspend fun resetAll() { context.settingsStore.edit { it.clear() } }

    private fun Preferences.toSettings() = AppSettings(
        theme = enumOr(this[themeKey], ThemeMode.SYSTEM),
        timeFormat = enumOr(this[formatKey], TimeFormat.SYSTEM),
    )

    private inline fun <reified T : Enum<T>> enumOr(raw: String?, default: T): T =
        enumValues<T>().firstOrNull { it.name == raw } ?: default
}
