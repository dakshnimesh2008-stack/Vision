package com.daksh.vision.ui.splash

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * The VISION mark: a clock ring with a V inside.
 * [ringSweep] 0..360 draws the ring progressively; [vAlpha] fades the V.
 */
@Composable
fun BrandMark(
    ringColor: Color,
    vColor: Color,
    modifier: Modifier = Modifier,
    size: Dp = 120.dp,
    ringSweep: Float = 360f,
    ringRotation: Float = 0f,
    vAlpha: Float = 1f,
) {
    Canvas(modifier.size(size)) {
        val w = this.size.width
        val stroke = w * 0.035f
        val inset = stroke
        // Ring starts at 12 o'clock like a clock's second hand.
        drawArc(
            color = ringColor,
            startAngle = -90f + ringRotation,
            sweepAngle = ringSweep,
            useCenter = false,
            topLeft = Offset(inset, inset),
            size = Size(w - inset * 2, w - inset * 2),
            style = Stroke(width = stroke, cap = StrokeCap.Round),
        )
        val v = Path().apply {
            moveTo(w * 0.33f, w * 0.38f)
            lineTo(w * 0.50f, w * 0.68f)
            lineTo(w * 0.67f, w * 0.38f)
        }
        drawPath(
            v, color = vColor.copy(alpha = vAlpha),
            style = Stroke(width = w * 0.055f, cap = StrokeCap.Round, join = StrokeJoin.Round),
        )
    }
}
