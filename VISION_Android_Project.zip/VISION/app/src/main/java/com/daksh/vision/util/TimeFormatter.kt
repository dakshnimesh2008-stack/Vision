package com.daksh.vision.util

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Pure formatting helpers (no Android dependencies, so they are unit-testable). */
object TimeFormatter {
    fun time(dt: LocalDateTime, use24h: Boolean, showSeconds: Boolean, locale: Locale = Locale.getDefault()): String {
        val pattern = when {
            use24h && showSeconds -> "HH:mm:ss"
            use24h -> "HH:mm"
            showSeconds -> "h:mm:ss"
            else -> "h:mm"
        }
        return dt.format(DateTimeFormatter.ofPattern(pattern, locale))
    }

    /** AM/PM marker, or empty string in 24-hour mode. */
    fun amPm(dt: LocalDateTime, use24h: Boolean, locale: Locale = Locale.getDefault()): String =
        if (use24h) "" else dt.format(DateTimeFormatter.ofPattern("a", locale))

    fun date(dt: LocalDateTime, locale: Locale = Locale.getDefault()): String =
        dt.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", locale))
}
